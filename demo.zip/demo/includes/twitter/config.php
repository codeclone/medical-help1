<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'XJF1UaAvSbnGGEUyPGbCeGGk2');
    define('CONSUMER_SECRET', 'bMbcLqiN4RUXzNFRcg9PvgPZSYxJHzCVeL2s6NDRArANcTEj35');

    // User Access Token
    define('ACCESS_TOKEN', '193244658-J33FPTK7jQlKkvOQKmrzuVuKtRo57ByFa9lRQcpS');
    define('ACCESS_SECRET', 'kq7e06phczDHrGQLojz25bZdxJ7YaWpL1aGrB14UocEvO');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));